
def exactly_K_extract_time_FFAST():
  times = []
  times.append(0.00132)
  time_results['FFAST'][50] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(0.00145)
  time_results['FFAST'][100] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(0.00147)
  time_results['FFAST'][200] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(0.00244)
  time_results['FFAST'][500] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(0.00363)
  time_results['FFAST'][1000] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  #times = []
  #time_results['FFAST'][2000] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  #time_results['FFAST'][4000] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)

def exactly_K_extract_time_MPSFT():
  times = []
  times.append(0.167)
  time_results['MPSFT'][50] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(0.271)
  time_results['MPSFT'][100] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(0.411)
  time_results['MPSFT'][200] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(0.746)
  time_results['MPSFT'][500] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(1.311)
  time_results['MPSFT'][1000] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(2.341)
  time_results['MPSFT'][2000] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  times = []
  times.append(4.402)
  time_results['MPSFT'][4000] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)


def exactly_K_extract_sample_sfftdt2():
  samples = []
  samples.append(100*math.pow(2, -10))
  sample_results['sfftdt2'][50] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -9))
  sample_results['sfftdt2'][100] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -8))
  sample_results['sfftdt2'][200] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -7))
  sample_results['sfftdt2'][500] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -6))
  sample_results['sfftdt2'][1000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -5))
  sample_results['sfftdt2'][2000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -4))
  sample_results['sfftdt2'][4000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)

def exactly_K_extract_sample_sfftdt3():
  samples = []
  samples.append(100*math.pow(2, -10))
  sample_results['sfftdt3'][50] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -9))
  sample_results['sfftdt3'][100] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -8))
  sample_results['sfftdt3'][200] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -7))
  sample_results['sfftdt3'][500] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -6))
  sample_results['sfftdt3'][1000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -5))
  sample_results['sfftdt3'][2000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  samples = []
  samples.append(100*math.pow(2, -4))
  sample_results['sfftdt3'][4000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)

def exactly_K_extract_sample_FFAST():
  samples = []
  samples.append(100*0.0023)
  sample_results['FFAST'][50] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  sample_results['FFAST'][100] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  sample_results['FFAST'][200] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  sample_results['FFAST'][500] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  sample_results['FFAST'][1000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  #samples = []
  #samples.append(0)
  #sample_results['FFAST'][2000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  #sample_results['FFAST'][4000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)

def exactly_K_extract_sample_sfft1():
  samples = []
  samples.append(100*501572/4194304)
  sample_results['sfft1-mit'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*427219/4194304)
  sample_results['sfft1-mit'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1137638/4194304)
  sample_results['sfft1-mit'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1871013/4194304)
  sample_results['sfft1-mit'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*2502675/4194304)
  sample_results['sfft1-mit'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*3321391/4197304)
  sample_results['sfft1-mit'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*4066914/4197304)
  sample_results['sfft1-mit'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def exactly_K_extract_sample_sfft2():
  samples = []
  samples.append(100*114961/4194304)
  sample_results['sfft2-mit'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*227583/4194304)
  sample_results['sfft2-mit'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*439108/4194304)
  sample_results['sfft2-mit'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*776925/4194304)
  sample_results['sfft2-mit'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*2052822/4194304)
  sample_results['sfft2-mit'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*2989892/4197304)
  sample_results['sfft2-mit'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*4024687/4197304)
  sample_results['sfft2-mit'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def exactly_K_extract_sample_sfft3():
  samples = []
  samples.append(100*2016/4194304)
  sample_results['sfft3-eth'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*4060/4194304)
  sample_results['sfft3-eth'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*8128/4194304)
  sample_results['sfft3-eth'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*23400/4194304)
  sample_results['sfft3-eth'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*46800/4194304)
  sample_results['sfft3-eth'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*93604/4197304)
  sample_results['sfft3-eth'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*187212/4197304)
  sample_results['sfft3-eth'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def exactly_K_extract_sample_sfft4():
  samples = []
  samples.append(100*38871/4194304)
  sample_results['sfft4'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*77742/4194304)
  sample_results['sfft4'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*138208/4194304)
  sample_results['sfft4'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*241864/4194304)
  sample_results['sfft4'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*483728/4194304)
  sample_results['sfft4'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*829248/4197304)
  sample_results['sfft4'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1382080/4197304)
  sample_results['sfft4'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def exactly_K_extract_sample_MPSFT():
  samples = []
  samples.append(100*120932/4194304)
  sample_results['MPSFT'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*224588/4194304)
  sample_results['MPSFT'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*414624/4194304)
  sample_results['MPSFT'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*760144/4194304)
  sample_results['MPSFT'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1382080/4194304)
  sample_results['MPSFT'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*2487744/4197304)
  sample_results['MPSFT'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*4197304/4197304)
  sample_results['MPSFT'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def exactly_K_extract_sample_fftw():
  samples = []
  samples.append(100*1)
  sample_results['fftw'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def exactly_K_extract_sample_aafft():
  samples = []
  samples.append(100*62934/4194304)
  sample_results['aafft'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*94660/4194304)
  sample_results['aafft'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*188079/4194304)
  sample_results['aafft'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*366395/4194304)
  sample_results['aafft'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*609203/4194304)
  sample_results['aafft'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1095225/4197304)
  sample_results['aafft'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1975253/4197304)
  sample_results['aafft'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

import math
import os
import random
import sys

from collections import namedtuple

import matplotlib.pyplot as plt

import matplotlib.ticker as mtick

from gen_input import gen_input
from helpers import make_data_point, write_data_points_to_file, \
    plot_data_points, Tee, data_stats_filename, index_filename, \
    data_filename, results_filename, plot_time_data_filename, \
    plot_l0_error_data_filename, script_output_filename
from run_experiment import run_experiment, extract_running_times, \
    num_l0_errors, write_index_file, extract_l0_errors, load_results_file, \
    num_l0_correct

tmpdir = '/home/local/data/noiseless_vs_k'
num_instances = 3
num_trials = 3
n = int(math.pow(2, 22))

kvals = [50, 100, 200, 500,1000,2000,4000]
#kvals = [2000]
l0_eps = 0.5
time_percentile_low = 0
time_percentile_high = 95
l0_error_percentile_low = 0
l0_error_percentile_high = 95
random.seed(7524019)
plot = True

sys.stdout = Tee(script_output_filename(tmpdir))

algs = ['sfft1-mit','fftw','aafft','sfftdt2','FFAST','sfft3-eth']
#algs = ['sfft1-mit', 'sfft2-mit','sfft4','MPSFT','sfft3-eth']
#algs = ['sfft1-mit', 'sfft2-mit','sfft4','MPSFT','fftw','aafft','sfftdt2','sfftdt3','FFAST','sfft3-eth']


time_results = {}
l0_results = {}
success_results = {}
sample_results = {}

for alg in algs:
  time_results[alg] = {}
  l0_results[alg] = {}
  success_results[alg] = {}
  sample_results[alg] = {}

for k in kvals:
  print ('k = {}'.format(k))
  print ('  generating input data ...')
  input_filename = []
  for instance in range(1, num_instances + 1):
    print ('    instance {}'.format(instance))
    dataf = data_filename(tmpdir, n, k, instance)
    gen_input(n, k, dataf, random.randint(0, 2000000000),
        stats_file=data_stats_filename(tmpdir, n, k, instance))
    input_filename.append(dataf)
  print ('  writing index file ...')
  indexf = index_filename(tmpdir, n, k)
  write_index_file(indexf, input_filename)
  for alg in algs:
    if (alg!='FFAST') and (alg!='MPSFT'):
      resultsf = results_filename(tmpdir, alg, n, k)
      print ('  algorithm: {}'.format(alg))
      r = run_experiment(n, k, indexf, alg, l0_eps, num_trials, seed=random.randint(0, 2000000000),output_file=resultsf)
      ne = num_l0_errors(r)
      if ne > 0:
        print ('    {} L0-errors occurred.'.format(ne))
  for f in input_filename:
    os.remove(f)

for k in kvals:
  for alg in algs:
    if (alg!='FFAST') and (alg!='MPSFT'):
      r = load_results_file(results_filename(tmpdir, alg, n, k))
      times = extract_running_times(r)
      time_results[alg][k] = make_data_point(times, time_percentile_low,
                                             time_percentile_high)
      l0_errors = extract_l0_errors(r)
      l0_results[alg][k] = make_data_point(l0_errors, l0_error_percentile_low,
                                           l0_error_percentile_high)
      success_results[alg][k] = float(num_l0_correct(r)) \
                                    / (num_instances * num_trials)


print ('\n')
print ('Time results:\n')
print (time_results)
print ('\n\nl0-error results:\n')
print (l0_results)
print ('\n\nSuccess results:\n')
print (success_results)

# pgfplot files
for alg in algs:
  if (alg != 'FFAST') and (alg != 'MPSFT'):
    write_data_points_to_file(time_results[alg],
                              plot_time_data_filename(tmpdir, alg),
                              'k', 'time')
    write_data_points_to_file(l0_results[alg],
                              plot_l0_error_data_filename(tmpdir, alg),
                              'k', 'l0_error')

exactly_K_extract_sample_fftw()
exactly_K_extract_sample_aafft()
exactly_K_extract_sample_sfftdt2()
#exactly_K_extract_sample_sfftdt3()
exactly_K_extract_sample_FFAST()
exactly_K_extract_sample_sfft1()
#exactly_K_extract_sample_sfft2()
exactly_K_extract_sample_sfft3()
#exactly_K_extract_sample_sfft4()
#exactly_K_extract_sample_MPSFT()


exactly_K_extract_time_FFAST()
#exactly_K_extract_time_MPSFT()

# Matplotlib
if plot:
  plt.figure(1)
  for alg in algs:
    plot_data_points(time_results[alg], plt, alg, '-x')
  plt.loglog(basex=10)
  plt.xlabel('k')
  plt.ylabel('time (s)')
  plt.title("Run Time vs Signal Sparsity (n=4194304)")
  plt.legend()
  plt.savefig('noiseless-k-time.png')

  plt.figure(2)
  for alg in algs:
    plot_data_points(l0_results[alg], plt, alg, 'x')
  plt.semilogx(basex=10)
  plt.xlabel('k')
  plt.ylabel('l0 error (l0-epsilon: {:e})'.format(l0_eps))
  plt.title("l0 error vs Signal Sparsity (n=4194304)")
  plt.legend()
  plt.savefig('noiseless-k-l0.png')

  plt.figure(3)
  for alg in algs:
    plot_data_points(sample_results[alg], plt, alg, '-x')
  plt.loglog(basex=10)
  fmt = '%.0f%%'   # Format you want the ticks, e.g. '40%'
  xticks = mtick.FormatStrFormatter(fmt)
  # Set the formatter
  axes = plt.gca()  # get current axes
  axes.yaxis.set_major_formatter(xticks)  # set % format to ystick.
  plt.xlabel('k')
  plt.ylabel('Percentage of Signal Sampled')
  plt.title("Percentage of Signal Sampled vs Signal Sparsity (n=4194304)")
  plt.legend()
  plt.savefig('noiseless-k-sample.png')

  plt.show()
