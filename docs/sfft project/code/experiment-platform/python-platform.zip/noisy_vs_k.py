def genally_K_extract_time_FFAST():
  times = []
  times.append(4.381)
  time_results['FFAST'][50] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(9.505)
  time_results['FFAST'][100] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(20.05)
  time_results['FFAST'][200] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(60.15)
  time_results['FFAST'][500] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(172.25)
  time_results['FFAST'][1000] = make_data_point(times, time_percentile_low, time_percentile_high)
  #times = []
  #time_results['FFAST'][2000] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)
  #time_results['FFAST'][4000] = make_data_point(times, l0_error_percentile_low, l0_error_percentile_high)

def genally_K_extract_time_MPSFT():
  times = []
  times.append(0.167)
  time_results['MPSFT'][50] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.271)
  time_results['MPSFT'][100] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.411)
  time_results['MPSFT'][200] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.746)
  time_results['MPSFT'][500] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.311)
  time_results['MPSFT'][1000] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(2.341)
  time_results['MPSFT'][2000] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(4.402)
  time_results['MPSFT'][4000] = make_data_point(times, time_percentile_low, time_percentile_high)

def genally_K_extract_l1_MPSFT():
  times = []
  times.append(0.0063)
  topk_l1_results['MPSFT'][50] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.0066)
  topk_l1_results['MPSFT'][100] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.0071)
  topk_l1_results['MPSFT'][200] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.0067)
  topk_l1_results['MPSFT'][500] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.0076)
  topk_l1_results['MPSFT'][1000] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.0077)
  topk_l1_results['MPSFT'][2000] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.0079)
  topk_l1_results['MPSFT'][4000] = make_data_point(times, time_percentile_low, time_percentile_high)

def genally_K_extract_sample_sfftdt2():
  samples = []
  samples.append(math.pow(2, -5)*100)
  sample_results['sfftdt2'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -5)*100)
  sample_results['sfftdt2'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -5)*100)
  sample_results['sfftdt2'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -5)*100)
  sample_results['sfftdt2'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -5)*100)
  sample_results['sfftdt2'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -5)*100)
  sample_results['sfftdt2'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -4)*100)
  sample_results['sfftdt2'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_K_extract_sample_sfftdt3():
  samples = []
  samples.append(math.pow(2, -6)*100)
  sample_results['sfftdt3'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -6)*100)
  sample_results['sfftdt3'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -6)*100)
  sample_results['sfftdt3'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -6)*100)
  sample_results['sfftdt3'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -6)*100)
  sample_results['sfftdt3'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -5)*100)
  sample_results['sfftdt3'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(math.pow(2, -4)*100)
  sample_results['sfftdt3'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_K_extract_sample_FFAST():
  samples = []
  samples.append(0.0016*100)
  sample_results['FFAST'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['FFAST'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['FFAST'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['FFAST'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['FFAST'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  #samples = []
  #samples.append(0)
  #sample_results['FFAST'][2000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)
  #sample_results['FFAST'][4000] = make_data_point(samples, l0_error_percentile_low, l0_error_percentile_high)

def genally_K_extract_sample_sfft1():
  samples = []
  samples.append(100*501572/4194304)
  sample_results['sfft1-mit'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*427219/4194304)
  sample_results['sfft1-mit'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1137638/4194304)
  sample_results['sfft1-mit'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1871013/4194304)
  sample_results['sfft1-mit'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*2502675/4194304)
  sample_results['sfft1-mit'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*3321391/4197304)
  sample_results['sfft1-mit'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*4066914/4197304)
  sample_results['sfft1-mit'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_K_extract_sample_sfft2():
  samples = []
  samples.append(100*114961/4194304)
  sample_results['sfft2-mit'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*227583/4194304)
  sample_results['sfft2-mit'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*439108/4194304)
  sample_results['sfft2-mit'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*776925/4194304)
  sample_results['sfft2-mit'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*2052822/4194304)
  sample_results['sfft2-mit'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*2989892/4197304)
  sample_results['sfft2-mit'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*4024687/4197304)
  sample_results['sfft2-mit'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_K_extract_sample_sfft4():
  samples = []
  samples.append(100*38871/4194304)
  sample_results['sfft4'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*77742/4194304)
  sample_results['sfft4'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*138208/4194304)
  sample_results['sfft4'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*241864/4194304)
  sample_results['sfft4'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*483728/4194304)
  sample_results['sfft4'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*829248/4197304)
  sample_results['sfft4'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1382080/4197304)
  sample_results['sfft4'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_K_extract_sample_MPSFT():
  samples = []
  samples.append(100*120932/4194304)
  sample_results['MPSFT'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*224588/4194304)
  sample_results['MPSFT'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*414624/4194304)
  sample_results['MPSFT'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*760144/4194304)
  sample_results['MPSFT'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1382080/4194304)
  sample_results['MPSFT'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*2487744/4197304)
  sample_results['MPSFT'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*4197304/4197304)
  sample_results['MPSFT'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_K_extract_sample_fftw():
  samples = []
  samples.append(100*1)
  sample_results['fftw'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  sample_results['fftw'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_K_extract_sample_aafft():
  samples = []
  samples.append(100*62934/4194304)
  sample_results['aafft'][50] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*94660/4194304)
  sample_results['aafft'][100] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*188079/4194304)
  sample_results['aafft'][200] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*366395/4194304)
  sample_results['aafft'][500] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*609203/4194304)
  sample_results['aafft'][1000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1095225/4197304)
  sample_results['aafft'][2000] = make_data_point(samples, time_percentile_low, time_percentile_high)
  samples = []
  samples.append(100*1975253/4197304)
  sample_results['aafft'][4000] = make_data_point(samples, time_percentile_low, time_percentile_high)

import math
import os
import random
import sys

from collections import namedtuple

import matplotlib.pyplot as plt

import matplotlib.ticker as mtick

from gen_input import gen_input, snr_db_to_noise_variance
from helpers import make_data_point, write_data_points_to_file, \
    plot_data_points, Tee, data_stats_filename_snr, index_filename_snr, \
    data_filename_snr, results_filename_snr, plot_time_data_filename, \
    plot_topk_l1_error_per_entry_data_filename, script_output_filename, \
    plot_relative_l2_l2_error_data_filename
from run_experiment import run_experiment, extract_running_times, \
    write_index_file, extract_topk_l1_errors, load_results_file, \
    compute_relative_l2_l2_errors

tmpdir = '/home/local/data/noisy_vs_k'
num_instances = 3
num_trials = 3
n = int(math.pow(2, 22))
kvals = [50, 100, 200, 500, 1000, 2000,4000]
#kvals = [50]
snr = 20
l0_eps = 0.5
relative_l2_l2_error_threshold = 1.3
time_percentile_low = 0
time_percentile_high = 95
topk_l1_error_percentile_low = 0
topk_l1_error_percentile_high = 95
relative_l2_l2_error_percentile_low = 0
relative_l2_l2_error_percentile_high = 95
random.seed(4527982)
#plot = False
plot = True

sys.stdout = Tee(script_output_filename(tmpdir))

algs = ['sfft1-mit', 'sfft2-mit','sfft1-eth','sfft2-eth']
#algs = ['sfft1-mit', 'sfft4','fftw','aafft','sfftdt2','FFAST']
#algs = ['sfft1-mit', 'sfft2-mit','sfft4','MPSFT']
#algs = ['sfft1-mit', 'sfft2-mit','sfft4','MPSFT','fftw','aafft','sfftdt2','sfftdt3','FFAST']


time_results = {}
topk_l1_results = {}
relative_l2_l2_results = {}
sample_results = {}

for alg in algs:
  time_results[alg] = {}
  topk_l1_results[alg] = {}
  relative_l2_l2_results[alg] = {}
  sample_results[alg] = {}

for k in kvals:
  print ('k = {}'.format(k))
  print ('  generating input data ...')
  input_filename = []
  for instance in range(1, num_instances + 1):
    print ('    instance {}'.format(instance))
    dataf = data_filename_snr(tmpdir, n, k, snr, instance)
    gen_input(n, k, dataf, seed=random.randint(0, 2000000000),
        stats_file=data_stats_filename_snr(tmpdir, n, k, snr, instance),
        noise_variance=snr_db_to_noise_variance(snr, n, k),
        randomize_phase=True)
    input_filename.append(dataf)
  print ('  writing index file ...')
  indexf = index_filename_snr(tmpdir, n, k, snr)
  write_index_file(indexf, input_filename)
  for alg in algs:
    if (alg!='FFAST') and (alg!='MPSFT'):
        resultsf = results_filename_snr(tmpdir, alg, n, k, snr)
        print ('  algorithm: {}'.format(alg))
        r = run_experiment(n, k, indexf, alg, l0_eps, num_trials,
            seed=random.randint(0, 2000000000), output_file=resultsf)
        rel_l2_l2 = compute_relative_l2_l2_errors(r)
        ne = 0
        for err in rel_l2_l2:
          if err > relative_l2_l2_error_threshold:
            ne += 1
    #if ne > 0:
    #  print ('    {} large l2/l2-errors occurred (threshold: {}).').format(ne,
    #      relative_l2_l2_error_threshold)

  for f in input_filename:
    os.remove(f)



for k in kvals:
  for alg in algs:
    if (alg!='FFAST') and (alg!='MPSFT'):
        r = load_results_file(results_filename_snr(tmpdir, alg, n, k, snr))
        times = extract_running_times(r)
        time_results[alg][k] = make_data_point(times, time_percentile_low,
                                               time_percentile_high)
        topk_l1_errors = extract_topk_l1_errors(r)
        for i in range(len(topk_l1_errors)):
          topk_l1_errors[i] = float(topk_l1_errors[i]) / k
        topk_l1_results[alg][k] = make_data_point(topk_l1_errors,
                                                  topk_l1_error_percentile_low,
                                                  topk_l1_error_percentile_high)

        l2_l2_errors = compute_relative_l2_l2_errors(r)
        relative_l2_l2_results[alg][k] = make_data_point(l2_l2_errors,
            relative_l2_l2_error_percentile_high,
            relative_l2_l2_error_percentile_low)



print ('\n')
print ('Time results:\n')
print (time_results)
print ('\n\naverage top-k l1-error results:\n')
print (topk_l1_results)
print ('\n\nRelative l2/l2 errors:\n')
print (relative_l2_l2_results)

# pgfplot files
for alg in algs:
  if (alg != 'FFAST') and (alg != 'MPSFT'):
      write_data_points_to_file(time_results[alg],
                                plot_time_data_filename(tmpdir, alg),
                                'k', 'time')
      write_data_points_to_file(topk_l1_results[alg],
                                plot_topk_l1_error_per_entry_data_filename(tmpdir,
                                    alg),
                                'k', 'topk_l1_error_per_entry')
      write_data_points_to_file(relative_l2_l2_results[alg],
                                plot_relative_l2_l2_error_data_filename(tmpdir,
                                    alg), 'k', 'relative_l2_l2_error')
# Matplotlib

#genally_K_extract_sample_fftw()
#genally_K_extract_sample_aafft()
#genally_K_extract_sample_sfftdt2()
#genally_K_extract_sample_sfftdt3()
#genally_K_extract_sample_FFAST()
#genally_K_extract_sample_sfft1()
#genally_K_extract_sample_sfft2()
#genally_K_extract_sample_sfft4()
#genally_K_extract_sample_MPSFT()


#genally_K_extract_time_FFAST()
#genally_K_extract_time_MPSFT()
#genally_K_extract_l1_MPSFT()

if plot:
  plt.figure(1)
  for alg in algs:
    plot_data_points(time_results[alg], plt, alg, '-x')
  plt.loglog(basex=10)
  plt.xlabel('k')
  plt.ylabel('time (s)')
  plt.title("Run Time vs Signal Sparsity (n=4194304)")
  plt.legend()
  plt.savefig('noisy-k-time.png')

  plt.figure(2)
  for alg in algs:
    plot_data_points(topk_l1_results[alg], plt, alg, '-x')
  plt.semilogx(basex=10)
  plt.xlabel('k')
  plt.ylabel('top-k l1 error per entry')
  plt.title("l1 error vs Signal Sparsity (n=4194304)")
  plt.legend()
  plt.savefig('noisy-k-l1.png')

  plt.figure(3)
  for alg in algs:
    plot_data_points(relative_l2_l2_results[alg], plt, alg, '-j')
  plt.semilogx(basex=10)
  plt.xlabel('k')
  plt.ylabel('relative l2/l2 error')
  plt.title("l2 error vs Signal Sparsity (n=4194304)")
  plt.legend()
  plt.savefig('noisy-k-l2.png')


  plt.figure(4)
  for alg in algs:
    plot_data_points(sample_results[alg], plt, alg, '-x')
  plt.loglog(basex=10)
  fmt = '%.0f%%'   # Format you want the ticks, e.g. '40%'
  xticks = mtick.FormatStrFormatter(fmt)
  # Set the formatter
  axes = plt.gca()  # get current axes
  axes.yaxis.set_major_formatter(xticks)  # set % format to ystick.
  plt.xlabel('k')
  plt.ylabel('Percentage of Signal Sampled')
  plt.title("Percentage of Signal Sampled vs Signal Sparsity (n=4194304)")
  plt.legend()
  plt.savefig('noisy-k-sample.png')

  plt.show()
