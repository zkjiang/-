def genally_N_extract_time_FFAST():
    times = []
    times.append(0.0724)
    time_results['FFAST'][8192] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.126)
    time_results['FFAST'][8192 * 2] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.158)
    time_results['FFAST'][8192 * 4] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.302)
    time_results['FFAST'][8192 * 8] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.455)
    time_results['FFAST'][8192 * 16] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.613)
    time_results['FFAST'][8192 * 32] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.919)
    time_results['FFAST'][8192 * 64] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(1.712)
    time_results['FFAST'][8192 * 128] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(2.526)
    time_results['FFAST'][8192 * 256] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(4.017)
    time_results['FFAST'][8192 * 512] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(6.33)
    time_results['FFAST'][8192 * 1024] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(11.2)
    time_results['FFAST'][8192 * 2048] = make_data_point(times, time_percentile_low, time_percentile_high)

def genally_N_extract_time_MPSFT():
    times = []
    times.append(0.061)
    time_results['MPSFT'][8192] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.068)
    time_results['MPSFT'][8192 * 2] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.080)
    time_results['MPSFT'][8192 * 4] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.086)
    time_results['MPSFT'][8192 * 8] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.092)
    time_results['MPSFT'][8192 * 16] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.098)
    time_results['MPSFT'][8192 * 32] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.117)
    time_results['MPSFT'][8192 * 64] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.145)
    time_results['MPSFT'][8192 * 128] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.150)
    time_results['MPSFT'][8192 * 256] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.161)
    time_results['MPSFT'][8192 * 512] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.186)
    time_results['MPSFT'][8192 * 1024] = make_data_point(times, time_percentile_low, time_percentile_high)
    times = []
    times.append(0.189)
    time_results['MPSFT'][8192 * 2048] = make_data_point(times, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_sfftdt2():
    samples = []
    samples.append(100*math.pow(2, -1))
    sample_results['sfftdt2'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -2))
    sample_results['sfftdt2'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -3))
    sample_results['sfftdt2'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -4))
    sample_results['sfftdt2'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt2'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt2'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt2'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt2'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt2'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt2'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt2'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt2'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_sfftdt3():
    samples = []
    samples.append(100*math.pow(2, -1))
    sample_results['sfftdt3'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -2))
    sample_results['sfftdt3'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -3))
    sample_results['sfftdt3'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -4))
    sample_results['sfftdt3'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -5))
    sample_results['sfftdt3'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -6))
    sample_results['sfftdt3'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -6))
    sample_results['sfftdt3'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -6))
    sample_results['sfftdt3'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -6))
    sample_results['sfftdt3'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -6))
    sample_results['sfftdt3'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -6))
    sample_results['sfftdt3'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*math.pow(2, -6))
    sample_results['sfftdt3'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_FFAST():
    samples = []
    samples.append(100*0.0575)
    sample_results['FFAST'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0381)
    sample_results['FFAST'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0228)
    sample_results['FFAST'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0182)
    sample_results['FFAST'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0116)
    sample_results['FFAST'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0072)
    sample_results['FFAST'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0046)
    sample_results['FFAST'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0035)
    sample_results['FFAST'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0022)
    sample_results['FFAST'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.0014)
    sample_results['FFAST'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.00087)
    sample_results['FFAST'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*0.00064)
    sample_results['FFAST'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_sfft1():
    samples = []
    samples.append(100*1)
    sample_results['sfft1-mit'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*1)
    sample_results['sfft1-mit'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*32637/32768)
    sample_results['sfft1-mit'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*63592/65536)
    sample_results['sfft1-mit'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*91808/131072)
    sample_results['sfft1-mit'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*119963/262144)
    sample_results['sfft1-mit'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*137036/524288)
    sample_results['sfft1-mit'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*245050/1048576)
    sample_results['sfft1-mit'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*333014/2097152)
    sample_results['sfft1-mit'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*501640/4197304)
    sample_results['sfft1-mit'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*587675/8388608)
    sample_results['sfft1-mit'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*957480/16777216)
    sample_results['sfft1-mit'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_sfft2():
    samples = []
    samples.append(100*1)
    sample_results['sfft2-mit'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*1)
    sample_results['sfft2-mit'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*32649/32768)
    sample_results['sfft2-mit'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*63494/65536)
    sample_results['sfft2-mit'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*80112/131072)
    sample_results['sfft2-mit'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*100527/262144)
    sample_results['sfft2-mit'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*91680/524288)
    sample_results['sfft2-mit'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*127010/1048576)
    sample_results['sfft2-mit'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*93150/2097152)
    sample_results['sfft2-mit'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*114987/4197304)
    sample_results['sfft2-mit'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*159682/8388608)
    sample_results['sfft2-mit'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*221721/16777216)
    sample_results['sfft2-mit'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_sfft4():
    samples = []
    samples.append(100*8192/8192)
    sample_results['sfft4'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*16384/16384)
    sample_results['sfft4'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*21595/32768)
    sample_results['sfft4'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*21595/65536)
    sample_results['sfft4'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*25914/131072)
    sample_results['sfft4'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*30233/262144)
    sample_results['sfft4'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*34552/524288)
    sample_results['sfft4'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*38871/1048576)
    sample_results['sfft4'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*38871/2097152)
    sample_results['sfft4'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*43190/4197304)
    sample_results['sfft4'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*47509/8388608)
    sample_results['sfft4'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*47509/16777216)
    sample_results['sfft4'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_MPSFT():
    samples = []
    samples.append(100*8191/8191)
    sample_results['MPSFT'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*16381/16381)
    sample_results['MPSFT'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*32771/32771)
    sample_results['MPSFT'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*65537/65537)
    sample_results['MPSFT'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*77742/131071)
    sample_results['MPSFT'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*86380/262147)
    sample_results['MPSFT'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*95018/524287)
    sample_results['MPSFT'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*103056/1048573)
    sample_results['MPSFT'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*112294/2097143)
    sample_results['MPSFT'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*120932/4194301)
    sample_results['MPSFT'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*129570/8388617)
    sample_results['MPSFT'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*138208/16777213)
    sample_results['MPSFT'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_fftw():
    samples = []
    samples.append(100*1)
    sample_results['fftw'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    sample_results['fftw'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

def genally_N_extract_sample_aafft():
    samples = []
    samples.append(100*8167/8192)
    sample_results['aafft'][8192] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*15523/16384)
    sample_results['aafft'][8192 * 2] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*25933/32768)
    sample_results['aafft'][8192 * 4] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*36012/65536)
    sample_results['aafft'][8192 * 8] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*44648/131072)
    sample_results['aafft'][8192 * 16] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*50612/262144)
    sample_results['aafft'][8192 * 32] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*51312/524288)
    sample_results['aafft'][8192 * 64] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*57871/1048576)
    sample_results['aafft'][8192 * 128] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*60610/2097152)
    sample_results['aafft'][8192 * 256] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*62908/4197304)
    sample_results['aafft'][8192 * 512] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*65057/8388608)
    sample_results['aafft'][8192 * 1024] = make_data_point(samples, time_percentile_low, time_percentile_high)
    samples = []
    samples.append(100*67085/16777216)
    sample_results['aafft'][8192 * 2048] = make_data_point(samples, time_percentile_low, time_percentile_high)

import math
import os
import random
import sys

from collections import namedtuple

import matplotlib.pyplot as plt

import matplotlib.ticker as mtick

from gen_input import gen_input, snr_db_to_noise_variance
from helpers import make_data_point, write_data_points_to_file, \
    plot_data_points, Tee, data_stats_filename_snr, index_filename_snr, \
    data_filename_snr, results_filename_snr, plot_time_data_filename, \
    plot_topk_l1_error_per_entry_data_filename, script_output_filename, \
    plot_relative_l2_l2_error_data_filename
from run_experiment import run_experiment, extract_running_times, \
    write_index_file, extract_topk_l1_errors, load_results_file, \
    compute_relative_l2_l2_errors

tmpdir = '/home/local/data/noisy_vs_n'
#num_instances = 2
num_instances = 3
#num_trials = 2
num_trials = 3
#exp1 = 14
#exp2 = 24
exp1 = 13
exp2 = 24
k = 50
snr = 20
l0_eps = 1e-8
relative_l2_l2_error_threshold = 1.3
time_percentile_low = 0
time_percentile_high = 95
topk_l1_error_percentile_low = 0
topk_l1_error_percentile_high = 95
relative_l2_l2_error_percentile_low = 0
relative_l2_l2_error_percentile_high = 95
random.seed(6728420)
#plot = False
plot = True

sys.stdout = Tee(script_output_filename(tmpdir))

algs = ['sfft1-mit', 'sfft2-mit','sfft1-eth','sfft2-eth']
#algs = ['sfft1-mit', 'sfft4','fftw','aafft','sfftdt2','FFAST']
#algs = ['sfft1-mit', 'sfft2-mit','sfft4','MPSFT']
#algs = ['sfft1-mit', 'sfft2-mit','sfft4','MPSFT','fftw','aafft','sfftdt2','sfftdt3','FFAST']


time_results = {}
topk_l1_results = {}
relative_l2_l2_results = {}
sample_results = {}

for alg in algs:
  time_results[alg] = {}
  topk_l1_results[alg] = {}
  relative_l2_l2_results[alg] = {}
  sample_results[alg] = {}


nvals = [int(math.pow(2, exp)) for exp in range(exp1, exp2 + 1)]

for n in nvals:
  print ('n = {}'.format(n))
  print ('  generating input data ...')
  input_filename = []
  for instance in range(1, num_instances + 1):
    print ('    instance {}'.format(instance))
    dataf = data_filename_snr(tmpdir, n, k, snr, instance)
    gen_input(n, k, dataf, seed=random.randint(0, 2000000000),
        stats_file=data_stats_filename_snr(tmpdir, n, k, snr, instance),
        noise_variance=snr_db_to_noise_variance(snr, n, k),
        randomize_phase=True)
    input_filename.append(dataf)
  print ('  writing index file ...')
  indexf = index_filename_snr(tmpdir, n, k, snr)
  write_index_file(indexf, input_filename)
  for alg in algs:
    if (alg!='FFAST') and (alg!='MPSFT'):
        resultsf = results_filename_snr(tmpdir, alg, n, k, snr)
        print ('  algorithm: {}'.format(alg))
        r = run_experiment(n, k, indexf, alg, l0_eps, num_trials,
            seed=random.randint(0, 2000000000), output_file=resultsf)
    #rel_l2_l2 = compute_relative_l2_l2_errors(r)
    #ne = 0
    #for err in rel_l2_l2:
    #  if err > relative_l2_l2_error_threshold:
    #    ne += 1
    #if ne > 0:
    #  print ('    {} large l2/l2-errors occurred (threshold: {}).'.format(ne,
    #      relative_l2_l2_error_threshold))

  for f in input_filename:
    os.remove(f)



for n in nvals:
  for alg in algs:
    if (alg!='FFAST') and (alg!='MPSFT'):
        r = load_results_file(results_filename_snr(tmpdir, alg, n, k, snr))
        times = extract_running_times(r)
        time_results[alg][n] = make_data_point(times, time_percentile_low,
                                               time_percentile_high)
        topk_l1_errors = extract_topk_l1_errors(r)
        for i in range(len(topk_l1_errors)):
          topk_l1_errors[i] = float(topk_l1_errors[i]) / k
        topk_l1_results[alg][n] = make_data_point(topk_l1_errors,
                                                  topk_l1_error_percentile_low,
                                                  topk_l1_error_percentile_high)

        l2_l2_errors = compute_relative_l2_l2_errors(r)
        relative_l2_l2_results[alg][n] = make_data_point(l2_l2_errors,
            relative_l2_l2_error_percentile_high,
            relative_l2_l2_error_percentile_low)


print ('\n')
print ('Time results:\n')
print (time_results)
print ('\n\naverage top-k l1-error results:\n')
print (topk_l1_results)
print ('\n\nRelative l2/l2 errors:\n')
print (relative_l2_l2_results)

# pgfplot files
for alg in algs:
  if (alg != 'FFAST') and (alg != 'MPSFT'):
      write_data_points_to_file(time_results[alg],
                                plot_time_data_filename(tmpdir, alg),
                                'n', 'time')
      write_data_points_to_file(topk_l1_results[alg],
                                plot_topk_l1_error_per_entry_data_filename(tmpdir,
                                    alg),
                                'n', 'topk_l1_error_per_entry')
      write_data_points_to_file(relative_l2_l2_results[alg],
                                plot_relative_l2_l2_error_data_filename(tmpdir,
                                    alg), 'n', 'relative_l2_l2_error')

#genally_N_extract_sample_fftw()
#genally_N_extract_sample_aafft()
#genally_N_extract_sample_sfftdt2()
#genally_N_extract_sample_sfftdt3()
#genally_N_extract_sample_FFAST()
#genally_N_extract_sample_sfft1()
#genally_N_extract_sample_sfft2()
#genally_N_extract_sample_sfft4()
#genally_N_extract_sample_MPSFT()


#genally_N_extract_time_FFAST()
#genally_N_extract_time_MPSFT()

# Matplotlib
if plot:
  plt.figure(1)
  for alg in algs:
    plot_data_points(time_results[alg], plt, alg, '-x')
  plt.loglog(basex=2)
  plt.xlabel('n')
  plt.ylabel('time (s)')
  plt.title("Run Time vs Signal Size (k=50)")
  plt.legend()
  plt.savefig('noisy-n-time.png')

  plt.figure(2)
  for alg in algs:
    plot_data_points(topk_l1_results[alg], plt, alg, '-x')
  plt.semilogx(basex=2)
  plt.xlabel('n')
  plt.ylabel('top-k l1 error per entry')
  plt.title("l1 error vs Signal Size (k=50)")
  plt.legend()
  plt.savefig('noisy-n-l1.png')

  plt.figure(3)
  for alg in algs:
    plot_data_points(relative_l2_l2_results[alg], plt, alg, '-j')
  plt.semilogx(basex=2)
  plt.xlabel('n')
  plt.ylabel('relative l2/l2 error')
  plt.title("l2 error vs Signal Size (k=50)")
  plt.legend()
  plt.savefig('noisy-n-l2.png')

  plt.figure(4)
  for alg in algs:
    plot_data_points(sample_results[alg], plt, alg, '-x')
  plt.loglog(basex=2)
  fmt = '%.0f%%'   # Format you want the ticks, e.g. '40%'
  xticks = mtick.FormatStrFormatter(fmt)
  # Set the formatter
  axes = plt.gca()  # get current axes
  axes.yaxis.set_major_formatter(xticks)  # set % format to ystick.
  plt.xlabel('n')
  plt.ylabel('Percentage of Signal Sampled')
  plt.title("Percentage of Signal Sampled vs Signal Size (k=50)")
  plt.legend()
  plt.savefig('noisy-n-sample.png')

  plt.show()
