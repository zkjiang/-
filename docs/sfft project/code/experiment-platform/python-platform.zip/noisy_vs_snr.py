def genally_SNR_extract_time_MPSFT():
  times = []
  times.append(0.174)
  time_results['MPSFT'][-20] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.171)
  time_results['MPSFT'][-10] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.178)
  time_results['MPSFT'][0] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.175)
  time_results['MPSFT'][10] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.179)
  time_results['MPSFT'][20] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.1823)
  time_results['MPSFT'][30] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.1765)
  time_results['MPSFT'][40] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.1789)
  time_results['MPSFT'][50] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.1784)
  time_results['MPSFT'][60] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.1687)
  time_results['MPSFT'][70] = make_data_point(times, time_percentile_low, time_percentile_high)

def genally_SNR_extract_l1_MPSFT():
  times = []
  times.append(1.12)
  topk_l1_results['MPSFT'][-20] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.045)
  topk_l1_results['MPSFT'][-10] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.019)
  topk_l1_results['MPSFT'][0] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.0058)
  topk_l1_results['MPSFT'][10] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.0022)
  topk_l1_results['MPSFT'][20] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.00072)
  topk_l1_results['MPSFT'][30] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.000265)
  topk_l1_results['MPSFT'][40] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.000098)
  topk_l1_results['MPSFT'][50] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.000042)
  topk_l1_results['MPSFT'][60] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(0.000011)
  topk_l1_results['MPSFT'][70] = make_data_point(times, time_percentile_low, time_percentile_high)

def genally_SNR_extract_l2_MPSFT():
  times = []
  times.append(1.074)
  relative_l2_l2_results['MPSFT'][-20] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.071)
  relative_l2_l2_results['MPSFT'][-10] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.068)
  relative_l2_l2_results['MPSFT'][0] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.075)
  relative_l2_l2_results['MPSFT'][10] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.079)
  relative_l2_l2_results['MPSFT'][20] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.073)
  relative_l2_l2_results['MPSFT'][30] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.07765)
  relative_l2_l2_results['MPSFT'][40] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.07789)
  relative_l2_l2_results['MPSFT'][50] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.06784)
  relative_l2_l2_results['MPSFT'][60] = make_data_point(times, time_percentile_low, time_percentile_high)
  times = []
  times.append(1.06687)
  relative_l2_l2_results['MPSFT'][70] = make_data_point(times, time_percentile_low, time_percentile_high)


import math
import os
import random
import sys

from collections import namedtuple

import matplotlib.pyplot as plt

plt.rcParams['axes.unicode_minus'] = False

from gen_input import gen_input, snr_db_to_noise_variance
from helpers import make_data_point, write_data_points_to_file, \
    plot_data_points, Tee, data_stats_filename_snr, index_filename_snr, \
    data_filename_snr, results_filename_snr, plot_time_data_filename, \
    plot_topk_l1_error_per_entry_data_filename, script_output_filename, \
    plot_relative_l2_l2_error_data_filename, db_to_ratio, ratio_to_db
from run_experiment import run_experiment, extract_running_times, \
    write_index_file, extract_topk_l1_errors, load_results_file, \
    compute_relative_l2_l2_errors

tmpdir = '/home/local/data/noisy_vs_snr'
#num_instances = 2
num_instances = 3
#num_trials = 2
num_trials = 3
n = int(math.pow(2, 22))
k = 50
#snr_db_vals = [-20, -10, -7, -3, 0, 3, 7, 10, 20, 30, 40, 50, 60, 120]
snr_db_vals = [-20, -10, 0, 10, 20, 30, 40, 50, 60, 70]

#snr_db_vals = [10, 20]
l0_eps = 1e-8
relative_l2_l2_error_threshold = 1.3
time_percentile_low = 0
time_percentile_high = 95
topk_l1_error_percentile_low = 0
topk_l1_error_percentile_high = 95
relative_l2_l2_error_percentile_low = 0
relative_l2_l2_error_percentile_high = 95
random.seed(14389295)
plot = True

sys.stdout = Tee(script_output_filename(tmpdir))

algs = ['sfft1-mit', 'sfft4','fftw','aafft','sfftdt2']
#algs = ['sfft1-mit', 'sfft2-mit','sfft4','MPSFT']
#algs = ['sfft1-mit', 'sfft2-mit','sfft4','MPSFT','fftw','aafft','sfftdt2','sfftdt3']




for snr in snr_db_vals:
  print ('snr = {} db  ({:.6e})'.format(snr, db_to_ratio(snr)))
  print ('  generating input data ...')
  input_filename = []
  for instance in range(1, num_instances + 1):
    print ('    instance {}'.format(instance))
    dataf = data_filename_snr(tmpdir, n, k, snr, instance)
    gen_input(n, k, dataf, seed=random.randint(0, 2000000000),
        stats_file=data_stats_filename_snr(tmpdir, n, k, snr, instance),
        noise_variance=snr_db_to_noise_variance(snr, n, k),
        randomize_phase=True)
    input_filename.append(dataf)
  print ('  writing index file ...')
  indexf = index_filename_snr(tmpdir, n, k, snr)
  write_index_file(indexf, input_filename)
  for alg in algs:
    if (alg!='MPSFT'):
        resultsf = results_filename_snr(tmpdir, alg, n, k, snr)
        print ('  algorithm: {}'.format(alg))
        r = run_experiment(n, k, indexf, alg, l0_eps, num_trials,
            seed=random.randint(0, 2000000000), output_file=resultsf)
        rel_l2_l2 = compute_relative_l2_l2_errors(r)
        ne = 0
        for err in rel_l2_l2:
          if err > relative_l2_l2_error_threshold:
            ne += 1
        if ne > 0:
          print ('    {} large l2/l2-errors occurred (threshold: {}).'.format(ne,
              relative_l2_l2_error_threshold))

  for f in input_filename:
    os.remove(f)

time_results = {}
topk_l1_results = {}
relative_l2_l2_results = {}

for alg in algs:
  time_results[alg] = {}
  topk_l1_results[alg] = {}
  relative_l2_l2_results[alg] = {}

for snr in snr_db_vals:
  for alg in algs:
    if (alg!='MPSFT'):
        r = load_results_file(results_filename_snr(tmpdir, alg, n, k, snr))
        times = extract_running_times(r)
        time_results[alg][snr] = make_data_point(times, time_percentile_low,
                                               time_percentile_high)
        topk_l1_errors = extract_topk_l1_errors(r)
        for i in range(len(topk_l1_errors)):
          topk_l1_errors[i] = float(topk_l1_errors[i]) / k
        topk_l1_results[alg][snr] = make_data_point(topk_l1_errors,
                                                    topk_l1_error_percentile_low,
                                                    topk_l1_error_percentile_high)

        l2_l2_errors = compute_relative_l2_l2_errors(r)
        relative_l2_l2_results[alg][snr] = make_data_point(l2_l2_errors,
            relative_l2_l2_error_percentile_high,
            relative_l2_l2_error_percentile_low)

print ('\n')
print ('Time results:\n')
print (time_results)
print ('\n\naverage top-k l1-error results:\n')
print (topk_l1_results)
print ('\n\nRelative l2/l2 errors:\n')
print (relative_l2_l2_results)

# pgfplot files
for alg in algs:
  if (alg != 'MPSFT'):
      write_data_points_to_file(time_results[alg],
                                plot_time_data_filename(tmpdir, alg),
                                'snr', 'time')
      write_data_points_to_file(topk_l1_results[alg],
                                plot_topk_l1_error_per_entry_data_filename(tmpdir,
                                    alg),
                                'snr', 'topk_l1_error_per_entry')
      write_data_points_to_file(relative_l2_l2_results[alg],
                                plot_relative_l2_l2_error_data_filename(tmpdir,
                                    alg), 'snr', 'relative_l2_l2_error')


#genally_SNR_extract_time_MPSFT()
#genally_SNR_extract_l1_MPSFT()
#genally_SNR_extract_l2_MPSFT()

# Matplotlib
if plot:
  plt.figure(1)
  for alg in algs:
    plot_data_points(time_results[alg], plt, alg, '-x')
  #plt.loglog(basex=10)
  plt.xlabel('SNR')
  plt.ylabel('time (s)')
  plt.title("Run Time vs SNR (n=4194304, k=50)")
  plt.legend()
  plt.savefig('noisy-snr-time.png')

  plt.figure(2)
  for alg in algs:
    plot_data_points(topk_l1_results[alg], plt, alg, '-x')
  #plt.semilogx(basex=10)
  plt.semilogy(basex=10)
  plt.xlabel('SNR')
  plt.ylabel('top-k l1 error per entry')
  plt.title("l1 error vs SNR (n=4194304, k=50)")
  plt.legend()
  plt.savefig('noisy-snr-l1.png')

  plt.figure(3)
  for alg in algs:
    plot_data_points(relative_l2_l2_results[alg], plt, alg, '-j')
  #plt.semilogx(basex=10)
  plt.semilogy(basex=10)
  plt.xlabel('SNR')
  plt.ylabel('relative l2/l2 error')
  plt.title("l2 error vs SNR (n=4194304, k=50)")
  plt.legend()
  plt.savefig('noisy-snr-l2.png')

  plt.show()
